
Michel Eter
----- NO PARTNER -----

Color:
Light orange 
R: 249 G: 172 B: 120


Dark orange for lettering 
R: 201 G: 82 B: 61


Monserrat extra light
<link href="https://fonts.googleapis.com/css?family=Montserrat:200,500" rel="stylesheet"> 

font-family: montserrat, sans-serif; font-weight: 200; font-style: normal;



Monserrat Medium
<link href="https://fonts.googleapis.com/css?family=Montserrat:200,500" rel="stylesheet"> 

font-family: montserrat, sans-serif; font-weight: 500; font-style: normal;



Navigation menu/ title/ body

Helvetica: font-family: helvetica;